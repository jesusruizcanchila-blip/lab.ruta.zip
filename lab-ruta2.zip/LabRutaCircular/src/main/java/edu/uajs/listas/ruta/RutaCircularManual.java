package edu.uajs.listas.ruta;

import java.util.ArrayList;
import java.util.List;

/**
 * PARTE 1 - RutaCircular circular SIN librerías (lista doblemente enlazada circular).
 *
 *            ┌────────────────────────────────────────────┐
 *            ▼                                            │
 *   primero → [A] ⇄ [B] ⇄ [C] ⇄ [D] ⇄ ... ⇄ [Z] ──────────┘
 *              ▲
 *            actual  (la parada que es la parada actual)
 *
 * Dos referencias:
 *   primero: la primera parada agregada. Como la lista es circular,
 *            el ÚLTIMO nodo siempre es  primero.anterior  (¡inserción al final en O(1)!)
 *   actual : la parada que está en servicio ahora
 */
public class RutaCircularManual implements RutaCircular {

    private Nodo primero;
    private Nodo actual;
    private int tamanio;

    // ══════════════════════ HITO 1: agregar ══════════════════════
    @Override
    public void agregar(Parada c) {
        Nodo nuevo = new Nodo(c);

        if (primero == null) {
            // Lista vacía: el nodo se apunta a sí mismo en ambos sentidos
            nuevo.siguiente = nuevo;
            nuevo.anterior = nuevo;
            primero = nuevo;
            actual = nuevo;
        } else {
            Nodo ultimo = primero.anterior;   // el último está "detrás" del primero

            nuevo.anterior = ultimo;      // 1.1: el nuevo viene después de 'ultimo'
            nuevo.siguiente = primero;    // 1.2: después del nuevo se vuelve a 'primero'
            ultimo.siguiente = nuevo;     // 1.3: 'ultimo' avanza hacia el nuevo
            primero.anterior = nuevo;     // 1.4: 'primero' retrocede hacia el nuevo (cierra el círculo)
        }
        tamanio++;
    }

    @Override
    public Parada actual() {
        return actual == null ? null : actual.dato;
    }

    // ══════════════════ HITO 2: siguiente / anterior ═════════════
    @Override
    public Parada siguiente() {
        if (actual == null) return null;
        actual = actual.siguiente;   // circular: no hay null, el siguiente del último es el primero
        return actual.dato;
    }

    @Override
    public Parada anterior() {
        if (actual == null) return null;
        actual = actual.anterior;    // circular: el anterior del primero es el último
        return actual.dato;
    }

    // ═════════════════ HITO 3: adelantar / retroceder N ══════════
    @Override
    public Parada saltar(int n) {
        if (actual == null) return null;

        n = n % tamanio;             // las vueltas completas no cambian nada (el signo se conserva)

        for (int i = 0; i < n; i++) {
            actual = actual.siguiente;
        }
        for (int i = 0; i > n; i--) {
            actual = actual.anterior;
        }
        return actual.dato;
    }

    // ═══════════════ HITO 4: eliminar la que es la parada actual ══════════════
    @Override
    public Parada eliminarActual() {
        if (actual == null) return null;               // vacía

        if (tamanio == 1) {                            // era la única
            primero = null;
            actual = null;
            tamanio = 0;
            return null;
        }

        // Caso general (hay al menos 2 paradas).
        Nodo previo = actual.anterior;
        Nodo proximo = actual.siguiente;

        previo.siguiente = proximo;   // 4.1: puentea hacia adelante
        proximo.anterior = previo;    // 4.2: puentea hacia atrás

        if (actual == primero) {      // 4.3: 'primero' no puede quedar apuntando a un nodo eliminado
            primero = proximo;
        }

        actual = proximo;             // 4.4: la siguiente parada pasa a ser la actual
        tamanio--;

        return actual.dato;           // 4.5
    }

    @Override
    public int tamanio() {
        return tamanio;
    }

    // ═════════ HITO 5: recorrer una vuelta con do-while ══════════
    @Override
    public int tiempoTotal() {
        if (primero == null) return 0;

        int total = 0;
        Nodo aux = primero;
        do {
            total += aux.dato.minutos();
            aux = aux.siguiente;
        } while (aux != primero);     // una sola vuelta: no hay null para detenerse
        return total;
    }

    @Override
    public List<String> nombresDesdeActual() {
        List<String> nombres = new ArrayList<>();
        if (actual == null) return nombres;
        Nodo aux = actual;
        do {
            nombres.add(aux.dato.nombre());
            aux = aux.siguiente;
        } while (aux != actual);
        return nombres;
    }
}