package edu.uajs.listas.ruta;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Random;

/**
 * PARTE 2 - La MISMA ruta, ahora CON librerías (java.util).
 *
 * java.util no trae lista circular. Igual que en clase, le damos comportamiento
 * circular a un LinkedList mediante ROTACIÓN. La regla del juego:
 *
 *     cola.getFirst()  →  la parada que es la parada actual ahora
 *
 *     siguiente  = el primero pasa al final   (removeFirst + addLast)
 *     anterior   = el último pasa al inicio   (removeLast  + addFirst)
 *     saltar(n)  = Collections.rotate(cola, -n)
 *
 * El "círculo" es lógico: internamente el último nodo sigue apuntando a null.
 */
public class RutaCircularLib implements RutaCircular {

    private final LinkedList<Parada> cola = new LinkedList<>();

    @Override
    public void agregar(Parada c) {
        cola.addLast(c);
    }

    @Override
    public Parada actual() {
        return cola.peekFirst();   // peekFirst devuelve null si está vacía; getFirst lanzaría excepción
    }

    @Override
    public Parada siguiente() {
        if (cola.isEmpty()) return null;
        cola.addLast(cola.removeFirst());
        return cola.peekFirst();
    }

    @Override
    public Parada anterior() {
        if (cola.isEmpty()) return null;
        cola.addFirst(cola.removeLast());
        return cola.peekFirst();
    }

    @Override
    public Parada saltar(int n) {
        if (cola.isEmpty()) return null;
        Collections.rotate(cola, -n);   // rotate(+d) mueve a la derecha; adelantar n = rotar -n
        return cola.peekFirst();
    }

    @Override
    public Parada eliminarActual() {
        if (cola.isEmpty()) return null;
        cola.removeFirst();
        return cola.peekFirst();
    }

    @Override
    public int tamanio() {
        return cola.size();
    }

    @Override
    public int tiempoTotal() {
        int total = 0;
        for (Parada p : cola) {
            total += p.minutos();
        }
        return total;
    }

    @Override
    public List<String> nombresDesdeActual() {
        // ListIterator: el iterador "con memoria de posición".
        List<String> nombres = new ArrayList<>();
        ListIterator<Parada> it = cola.listIterator();
        while (it.hasNext()) {
            nombres.add(it.next().nombre());
        }
        return nombres;
    }

    // ═════════ RETOS EXTRA ═════════

    /**
     * RETO EXTRA 1: salta directamente a una parada por título (ignore mayúsculas).
     * Devuelve false si no existe y no cambia nada.
     * Pista: ListIterator tiene nextIndex(); luego reutilice saltar(indice).
     */
    public boolean irA(String nombre) {
        ListIterator<Parada> it = cola.listIterator();
        while (it.hasNext()) {
            int indice = it.nextIndex();
            if (it.next().nombre().equalsIgnoreCase(nombre)) {
                saltar(indice);
                return true;
            }
        }
        return false;
    }

    /**
     * RETO EXTRA 2: recorrido alternativo. Reordene la cola con Collections.shuffle,
     * pasando  new Random(semilla)  para que sea repetible.
     */
    public void reordenar(long semilla) {
        Collections.shuffle(cola, new Random(semilla));
    }
}